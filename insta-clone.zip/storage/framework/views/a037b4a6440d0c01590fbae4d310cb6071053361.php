<div class="row">
    <div class="col col-md-4">
        <div class="mt-4 ml-4">
            <img class="rounded-circle" src="<?php echo e($user->profile->picture); ?>" alt="<?php echo e($user->profile->title); ?>" height="180px">
        </div>
    </div>

    <div class="col">
        <div class="row mt-4">
            <div class="col">
                <h2>
                    <?php echo e($user->username); ?>


                    <?php echo $__env->make('profiles.follow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </h2>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <p><strong><?php echo e($user->profile->title); ?></strong></p>
                <p><?php echo e($user->profile->bio); ?></p>
                <p><a href="//<?php echo e($user->profile->url); ?>" target="_blank"><?php echo e($user->profile->url); ?></a></p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Ravi\Desktop\Laravel\Day13\insta-clone\resources\views/profiles/summary.blade.php ENDPATH**/ ?>