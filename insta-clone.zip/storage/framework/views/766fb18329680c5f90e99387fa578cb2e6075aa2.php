<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-4">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <a href="<?php echo e(route('profile', [ 'user' => $post->username() ])); ?>" class="text-dark" style="text-decoration: none">
                                    <img src="<?php echo e($post->userProfilePic()); ?>" alt="<?php echo e($post->username()); ?>" class="rounded-circle" height="40px">
                                    <strong class="ml-1"><?php echo e($post->username()); ?></strong>
                                </a>
                            </div>

                            <a href="<?php echo e(route('p.show', [ 'post' => $post->id ])); ?>">
                              <img class="img-thumbnail" src="<?php echo e($post->postPicture()); ?>" alt="<?php echo e($post->caption); ?>">
                            </a>

                            <div class="card-body">
                                <strong><?php echo e($post->caption); ?></strong>
                                <a href="<?php if(auth()->guard()->check()): ?><?php echo e(route('p.like', [ 'uid' => Auth::user()->id, 'pid' => $post->id ])); ?><?php endif; ?>" class="btn <?php echo e($post->liked() ? 'btn-danger' : 'btn-light'); ?>">
                                    <i class="fa fa-heart"></i> <strong><?php echo e($post->likes()->count()); ?></strong>
                                </a>
                                <p><?php echo e($post->description); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="col">
            <div class="card">
                <div class="card-header">
                    <img src="<?php echo e(Auth::user()->profile->picture); ?>" alt="<?php echo e(Auth::user()->username); ?>" class="rounded-circle" height="40px">
                    <strong class="ml-1"><?php echo e(Auth::user()->username); ?></strong>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Desktop\Laravel\Day13\insta-clone\resources\views/home.blade.php ENDPATH**/ ?>