<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-8 pr-0">
                <img class="img-thumbnail" src="<?php echo e($post->postPicture()); ?>" alt="<?php echo e($post->caption); ?>">
            </div>

            <div class="col pl-0">
                <div class="card">
                    <div class="card-header">
                        <img src="<?php echo e($post->userProfilePic()); ?>" alt="<?php echo e($post->username()); ?>" class="rounded-circle" height="40px">
                        <strong class="ml-1"><?php echo e($post->username()); ?></strong>
                        <?php echo $__env->make('profiles.follow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="card-body">
                        <p><strong><?php echo e($post->caption); ?></strong></p>
                        <p><?php echo e($post->description); ?></p>

                        <a href="<?php if(auth()->guard()->check()): ?><?php echo e(route('p.like', [ 'uid' => Auth::user()->id, 'pid' => $post->id ])); ?><?php endif; ?>" class="btn <?php echo e($liked ? 'btn-danger' : 'btn-light'); ?>">
                            <i class="fa fa-heart"></i> <strong><?php echo e($post->likes()->count()); ?></strong>
                        </a>

                        <hr />
                        <div>
                            <h5>Comments</h5>
                            <?php if($post->comments()->count()): ?>
                                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentObj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <strong><?php echo e($commentObj->user->username); ?></strong>
                                        <?php echo e($commentObj->comment); ?>

                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="alert alert-info">No comments to show</div>
                            <?php endif; ?>
                        </div>

                        <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('p.comment', [ 'post' => $post->id ])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" class="form-control" name="comment" placeholder="Add Comment...">
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Desktop\Laravel\Day13\insta-clone\resources\views/posts/show.blade.php ENDPATH**/ ?>