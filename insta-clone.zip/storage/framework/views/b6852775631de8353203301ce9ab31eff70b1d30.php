<?php if(Auth::user() && Auth::user()->username != $user->username ): ?>
    <?php if($user->isFollower(Auth::user()->id)): ?>
    <a href="<?php echo e(route('unfollow', ['user' => $user->id])); ?>" class="btn btn-secondary btn-sm">Unfollow</a>
    <?php else: ?>
    <a href="<?php echo e(route('follow', ['user' => $user->id])); ?>" class="btn btn-primary btn-sm">Follow</a>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\Ravi\Desktop\Laravel\Day13\insta-clone\resources\views/profiles/follow.blade.php ENDPATH**/ ?>