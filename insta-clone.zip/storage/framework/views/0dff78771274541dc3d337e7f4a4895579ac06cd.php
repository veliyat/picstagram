<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row">
                <div class="col col-md-4">
                    <div class="mt-4 ml-4">
                        <img class="rounded-circle" src="<?php echo e($user->profile->picture); ?>" alt="<?php echo e($user->profile->title); ?>" height="180px">
                    </div>
                </div>

                <div class="col">
                    <div class="row mt-4">
                        <h2><?php echo e($user->username); ?></h2>
                        <a class="btn btn-primary btn-sm" href="#">Follow</a>
                    </div>

                    <div class="row">

                    </div>

                    <div class="row">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ravi\Desktop\Laravel\Day9\insta-clone\resources\views/profiles/index.blade.php ENDPATH**/ ?>